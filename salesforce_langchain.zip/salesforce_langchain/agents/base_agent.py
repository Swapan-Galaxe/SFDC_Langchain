"""
Base Agent Class - Foundation for all specialist agents
Provides async interface, shared utilities, and common patterns
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
import asyncio
from datetime import datetime
import os


class BaseAgent(ABC):
    """Abstract base class for all specialist agents"""
    
    def __init__(self, name: str, role: str, salesforce_agent, llm_client, callbacks: Optional[List] = None):
        self.name = name
        self.role = role
        self.salesforce_agent = salesforce_agent
        self.llm = llm_client
        # Optional LangChain-style callbacks (LangSmith tracer, etc.)
        self.callbacks = callbacks
        self.conversation_history: List[Dict[str, str]] = []
    
    @abstractmethod
    async def chat_async(self, message: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Process message and return response asynchronously"""
        pass
    
    @abstractmethod
    def get_capabilities(self) -> List[str]:
        """Return list of agent capabilities/keywords for routing"""
        pass
    
    def add_to_history(self, role: str, content: str):
        """Add message to conversation history"""
        self.conversation_history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
    
    def get_history(self, limit: Optional[int] = None) -> List[Dict[str, str]]:
        """Get conversation history, optionally limited to recent messages"""
        if limit:
            return self.conversation_history[-limit:]
        return self.conversation_history
    
    def clear_history(self):
        """Clear conversation history"""
        self.conversation_history = []
    
    async def _call_llm_async(self, messages: List[Dict[str, str]], temperature: float = 0.7) -> str:
        """Async wrapper for LLM calls"""
        loop = asyncio.get_event_loop()
        # If LangChain tracing is enabled and ChatOpenAI is available, prefer using it
        try:
            if os.getenv("LANGCHAIN_TRACING_V2", "false").lower() == "true":
                from langchain.chat_models import ChatOpenAI
                from langchain.schema import HumanMessage, SystemMessage, AIMessage

                lc_messages = []
                for m in messages:
                    role = m.get("role", "user")
                    content = m.get("content", "")
                    if role == "system":
                        lc_messages.append(SystemMessage(content=content))
                    elif role == "assistant":
                        lc_messages.append(AIMessage(content=content))
                    else:
                        lc_messages.append(HumanMessage(content=content))

                chat = ChatOpenAI(model="gpt-4", temperature=temperature, callbacks=self.callbacks if self.callbacks else None)
                # Use agenerate to keep async behavior
                result = await chat.agenerate([lc_messages])
                # Get the first generation text
                return result.generations[0][0].text
        except Exception:
            # Fall back to original OpenAI client usage
            pass

        response = await loop.run_in_executor(
            None,
            lambda: self.llm.chat.completions.create(
                model="gpt-4",
                messages=messages,
                temperature=temperature
            )
        )
        return response.choices[0].message.content
    
    def __repr__(self):
        return f"{self.__class__.__name__}(name='{self.name}', role='{self.role}')"
